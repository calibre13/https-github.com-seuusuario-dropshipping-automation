#!/bin/bash

# Script de Setup Rápido
# Configura e inicializa o sistema de automação de dropshipping

echo "🚀 Setup do Sistema de Automação de Dropshipping"
echo "=================================================="
echo ""

# Cores para output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Função para verificar se comando existe
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# 1. Verificar Python
echo "📌 Verificando Python..."
if ! command_exists python3; then
    echo -e "${RED}❌ Python 3 não encontrado${NC}"
    echo "   Instale Python 3.10+ de https://www.python.org/downloads/"
    exit 1
fi
PYTHON_VERSION=$(python3 --version)
echo -e "${GREEN}✓ $PYTHON_VERSION instalado${NC}"

# 2. Verificar pip
echo "📌 Verificando pip..."
if ! command_exists pip3; then
    echo -e "${RED}❌ pip não encontrado${NC}"
    exit 1
fi
echo -e "${GREEN}✓ pip instalado${NC}"

# 3. Verificar MongoDB
echo "📌 Verificando MongoDB..."
if ! command_exists mongosh && ! command_exists mongo; then
    echo -e "${YELLOW}⚠️  MongoDB não encontrado${NC}"
    echo "   Você precisa instalar MongoDB:"
    echo "   macOS: brew install mongodb-community"
    echo "   Ubuntu: sudo apt-get install mongodb"
    echo "   Windows: https://www.mongodb.com/try/download/community"
    echo ""
    read -p "Continuar sem MongoDB? (y/n) " -n 1 -r
    echo
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 1
    fi
else
    echo -e "${GREEN}✓ MongoDB instalado${NC}"
fi

# 4. Criar ambiente virtual
echo ""
echo "📦 Criando ambiente virtual..."
cd backend
if [ -d "venv" ]; then
    echo -e "${YELLOW}⚠️  Ambiente virtual já existe${NC}"
else
    python3 -m venv venv
    echo -e "${GREEN}✓ Ambiente virtual criado${NC}"
fi

# 5. Ativar ambiente virtual
echo "📌 Ativando ambiente virtual..."
source venv/bin/activate || . venv/Scripts/activate 2>/dev/null
echo -e "${GREEN}✓ Ambiente ativado${NC}"

# 6. Instalar dependências
echo ""
echo "📥 Instalando dependências..."
pip install -r requirements.txt
if [ $? -eq 0 ]; then
    echo -e "${GREEN}✓ Dependências instaladas${NC}"
else
    echo -e "${RED}❌ Erro ao instalar dependências${NC}"
    exit 1
fi

# 7. Configurar .env
echo ""
echo "⚙️  Configurando variáveis de ambiente..."
if [ -f ".env" ]; then
    echo -e "${YELLOW}⚠️  Arquivo .env já existe${NC}"
    read -p "Sobrescrever? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        cp .env.example .env
        echo -e "${GREEN}✓ .env criado${NC}"
    fi
else
    cp .env.example .env
    echo -e "${GREEN}✓ .env criado${NC}"
fi

# 8. Gerar chave JWT
echo "🔐 Gerando chave JWT secreta..."
JWT_SECRET=$(python3 -c "import secrets; print(secrets.token_urlsafe(32))")
sed -i.bak "s/your-secret-key-change-in-production/$JWT_SECRET/" .env
rm .env.bak 2>/dev/null
echo -e "${GREEN}✓ Chave JWT gerada${NC}"

# 9. Popular banco de dados
echo ""
read -p "🌱 Popular banco com dados de exemplo? (y/n) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    python seed_database.py
    if [ $? -eq 0 ]; then
        echo -e "${GREEN}✓ Banco populado${NC}"
    else
        echo -e "${YELLOW}⚠️  Erro ao popular banco (talvez MongoDB não esteja rodando)${NC}"
    fi
fi

# 10. Instruções finais
echo ""
echo "=================================================="
echo -e "${GREEN}✅ Setup Completo!${NC}"
echo "=================================================="
echo ""
echo "📝 Próximos passos:"
echo ""
echo "1. Certifique-se de que o MongoDB está rodando:"
echo "   macOS: brew services start mongodb-community"
echo "   Linux: sudo systemctl start mongodb"
echo ""
echo "2. Configure suas credenciais de API no arquivo .env"
echo ""
echo "3. Inicie o servidor:"
echo "   cd backend"
echo "   source venv/bin/activate  # ou: . venv/Scripts/activate (Windows)"
echo "   python server.py"
echo ""
echo "4. Acesse a API:"
echo "   http://localhost:8000"
echo "   http://localhost:8000/docs (Documentação)"
echo ""
echo "🔐 Credenciais de teste:"
echo "   Admin: admin@dropshipping.com / admin123"
echo "   Cliente: joao@email.com / cliente123"
echo ""
echo "🎉 Bom trabalho!"
