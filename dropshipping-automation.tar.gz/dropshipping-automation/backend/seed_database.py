"""
Script de Seed - Popula banco de dados com dados de exemplo
"""
import asyncio
import os
import sys
from motor.motor_asyncio import AsyncIOMotorClient
from datetime import datetime, timezone
import bcrypt

# Adiciona path do backend
sys.path.append(os.path.dirname(__file__))

MONGO_URL = os.getenv('MONGO_URL', 'mongodb://localhost:27017')
DB_NAME = os.getenv('DB_NAME', 'dropshipping_automation')


async def seed_database():
    """Popula banco de dados com dados de exemplo"""
    
    print("🌱 Iniciando seed do banco de dados...")
    
    # Conecta ao MongoDB
    client = AsyncIOMotorClient(MONGO_URL)
    db = client[DB_NAME]
    
    try:
        # Limpa coleções existentes (cuidado em produção!)
        print("🗑️  Limpando coleções existentes...")
        await db.users.delete_many({})
        await db.categories.delete_many({})
        await db.products.delete_many({})
        await db.carts.delete_many({})
        await db.orders.delete_many({})
        
        # ========== USUÁRIOS ==========
        print("👥 Criando usuários...")
        
        # Hash de senhas
        admin_hash = bcrypt.hashpw(b'admin123', bcrypt.gensalt()).decode('utf-8')
        user_hash = bcrypt.hashpw(b'cliente123', bcrypt.gensalt()).decode('utf-8')
        
        users = [
            {
                'id': 'admin-001',
                'name': 'Administrador',
                'email': 'admin@dropshipping.com',
                'password_hash': admin_hash,
                'role': 'admin',
                'phone': '11987654321',
                'created_at': datetime.now(timezone.utc)
            },
            {
                'id': 'user-001',
                'name': 'João Silva',
                'email': 'joao@email.com',
                'password_hash': user_hash,
                'role': 'client',
                'phone': '11912345678',
                'address': {
                    'street': 'Rua das Flores',
                    'number': '123',
                    'city': 'São Paulo',
                    'state': 'SP',
                    'zip': '01234-567'
                },
                'created_at': datetime.now(timezone.utc)
            }
        ]
        
        await db.users.insert_many(users)
        print(f"  ✓ {len(users)} usuários criados")
        
        # ========== CATEGORIAS ==========
        print("📁 Criando categorias...")
        
        categories = [
            {'id': 'cat-tech', 'name': 'Tecnologia', 'slug': 'tecnologia'},
            {'id': 'cat-fashion', 'name': 'Moda e Acessórios', 'slug': 'moda'},
            {'id': 'cat-home', 'name': 'Casa e Decoração', 'slug': 'casa'},
            {'id': 'cat-beauty', 'name': 'Beleza e Cuidados', 'slug': 'beleza'},
            {'id': 'cat-sports', 'name': 'Esportes e Fitness', 'slug': 'esportes'},
        ]
        
        await db.categories.insert_many(categories)
        print(f"  ✓ {len(categories)} categorias criadas")
        
        # ========== PRODUTOS ==========
        print("📦 Criando produtos de exemplo...")
        
        products = [
            # Tecnologia - AliExpress
            {
                'id': 'prod-001',
                'name': 'Fone de Ouvido Bluetooth TWS',
                'description': 'Fone sem fio com cancelamento de ruído, bateria de 24h',
                'price': 149.90,
                'cost': 89.90,
                'stock': 50,
                'is_available': True,
                'category': 'tecnologia',
                'image_url': 'https://via.placeholder.com/400x400.png?text=Fone+TWS',
                'supplier': 'aliexpress',
                'supplier_sku': 'ALI-TWS-001',
                'supplier_price_usd': 18.99,
                'margin_percentage': 40.0,
                'last_sync': datetime.now(timezone.utc),
                'created_at': datetime.now(timezone.utc)
            },
            {
                'id': 'prod-002',
                'name': 'Smartwatch Fitness Tracker',
                'description': 'Relógio inteligente com monitor cardíaco e GPS',
                'price': 299.90,
                'cost': 179.90,
                'stock': 30,
                'is_available': True,
                'category': 'tecnologia',
                'image_url': 'https://via.placeholder.com/400x400.png?text=Smartwatch',
                'supplier': 'aliexpress',
                'supplier_sku': 'ALI-WATCH-002',
                'supplier_price_usd': 35.99,
                'margin_percentage': 40.0,
                'last_sync': datetime.now(timezone.utc),
                'created_at': datetime.now(timezone.utc)
            },
            
            # Moda - Dropi (Fornecedor BR)
            {
                'id': 'prod-003',
                'name': 'Tênis Esportivo Masculino',
                'description': 'Tênis confortável para corrida e academia',
                'price': 189.90,
                'cost': 135.90,
                'stock': 40,
                'is_available': True,
                'category': 'moda',
                'image_url': 'https://via.placeholder.com/400x400.png?text=Tenis',
                'supplier': 'dropi',
                'supplier_sku': 'DROPI-SHOES-003',
                'supplier_price_brl': 135.90,
                'margin_percentage': 40.0,
                'last_sync': datetime.now(timezone.utc),
                'created_at': datetime.now(timezone.utc)
            },
            {
                'id': 'prod-004',
                'name': 'Mochila Executiva Premium',
                'description': 'Mochila anti-furto com porta USB, ideal para notebook',
                'price': 159.90,
                'cost': 99.90,
                'stock': 25,
                'is_available': True,
                'category': 'moda',
                'image_url': 'https://via.placeholder.com/400x400.png?text=Mochila',
                'supplier': 'dropi',
                'supplier_sku': 'DROPI-BAG-004',
                'supplier_price_brl': 99.90,
                'margin_percentage': 60.0,
                'last_sync': datetime.now(timezone.utc),
                'created_at': datetime.now(timezone.utc)
            },
            
            # Casa - Bling (Fornecedor BR com ERP)
            {
                'id': 'prod-005',
                'name': 'Organizador de Pia Multifuncional',
                'description': 'Suporte para detergente, esponja e sabão',
                'price': 79.90,
                'cost': 49.90,
                'stock': 60,
                'is_available': True,
                'category': 'casa',
                'image_url': 'https://via.placeholder.com/400x400.png?text=Organizador',
                'supplier': 'bling',
                'supplier_sku': 'BLING-ORG-005',
                'supplier_price_brl': 49.90,
                'margin_percentage': 60.0,
                'last_sync': datetime.now(timezone.utc),
                'created_at': datetime.now(timezone.utc)
            },
            {
                'id': 'prod-006',
                'name': 'Kit 3 Tapetes Antiderrapantes',
                'description': 'Tapetes para cozinha e banheiro',
                'price': 119.90,
                'cost': 79.90,
                'stock': 45,
                'is_available': True,
                'category': 'casa',
                'image_url': 'https://via.placeholder.com/400x400.png?text=Tapetes',
                'supplier': 'bling',
                'supplier_sku': 'BLING-MAT-006',
                'supplier_price_brl': 79.90,
                'margin_percentage': 50.0,
                'last_sync': datetime.now(timezone.utc),
                'created_at': datetime.now(timezone.utc)
            },
            
            # Beleza - AliExpress
            {
                'id': 'prod-007',
                'name': 'Escova Secadora 3 em 1',
                'description': 'Seca, alisa e modela em um único aparelho',
                'price': 199.90,
                'cost': 119.90,
                'stock': 35,
                'is_available': True,
                'category': 'beleza',
                'image_url': 'https://via.placeholder.com/400x400.png?text=Escova',
                'supplier': 'aliexpress',
                'supplier_sku': 'ALI-BRUSH-007',
                'supplier_price_usd': 23.99,
                'margin_percentage': 40.0,
                'last_sync': datetime.now(timezone.utc),
                'created_at': datetime.now(timezone.utc)
            },
            {
                'id': 'prod-008',
                'name': 'Kit Skincare 5 Passos',
                'description': 'Rotina completa de cuidados com a pele',
                'price': 249.90,
                'cost': 149.90,
                'stock': 20,
                'is_available': True,
                'category': 'beleza',
                'image_url': 'https://via.placeholder.com/400x400.png?text=Skincare',
                'supplier': 'dropi',
                'supplier_sku': 'DROPI-SKIN-008',
                'supplier_price_brl': 149.90,
                'margin_percentage': 40.0,
                'last_sync': datetime.now(timezone.utc),
                'created_at': datetime.now(timezone.utc)
            },
            
            # Esportes
            {
                'id': 'prod-009',
                'name': 'Garrafa Térmica 1L com Infusor',
                'description': 'Mantém líquidos gelados por 24h',
                'price': 89.90,
                'cost': 54.90,
                'stock': 70,
                'is_available': True,
                'category': 'esportes',
                'image_url': 'https://via.placeholder.com/400x400.png?text=Garrafa',
                'supplier': 'dropi',
                'supplier_sku': 'DROPI-BOTTLE-009',
                'supplier_price_brl': 54.90,
                'margin_percentage': 40.0,
                'last_sync': datetime.now(timezone.utc),
                'created_at': datetime.now(timezone.utc)
            },
            {
                'id': 'prod-010',
                'name': 'Kit Elásticos de Resistência 5 Níveis',
                'description': 'Para treino em casa, com ancoragem de porta',
                'price': 129.90,
                'cost': 77.90,
                'stock': 55,
                'is_available': True,
                'category': 'esportes',
                'image_url': 'https://via.placeholder.com/400x400.png?text=Elasticos',
                'supplier': 'aliexpress',
                'supplier_sku': 'ALI-BAND-010',
                'supplier_price_usd': 15.59,
                'margin_percentage': 40.0,
                'last_sync': datetime.now(timezone.utc),
                'created_at': datetime.now(timezone.utc)
            }
        ]
        
        await db.products.insert_many(products)
        print(f"  ✓ {len(products)} produtos criados")
        
        # ========== PEDIDO DE EXEMPLO ==========
        print("🛍️  Criando pedido de exemplo...")
        
        orders = [
            {
                'id': 'order-001',
                'user_id': 'user-001',
                'order_number': 'ORD000001',
                'items': [
                    {
                        'product_id': 'prod-001',
                        'name': 'Fone de Ouvido Bluetooth TWS',
                        'price': 149.90,
                        'quantity': 1
                    },
                    {
                        'product_id': 'prod-003',
                        'name': 'Tênis Esportivo Masculino',
                        'price': 189.90,
                        'quantity': 1
                    }
                ],
                'total': 339.80,
                'status': 'processing',
                'payment_method': 'pix',
                'shipping_address': {
                    'street': 'Rua das Flores',
                    'number': '123',
                    'city': 'São Paulo',
                    'state': 'SP',
                    'zip': '01234-567'
                },
                'created_at': datetime.now(timezone.utc),
                'updated_at': datetime.now(timezone.utc)
            }
        ]
        
        await db.orders.insert_many(orders)
        print(f"  ✓ {len(orders)} pedido(s) criado(s)")
        
        print("\n✅ Seed completo!")
        print("\n📊 Resumo:")
        print(f"   👥 Usuários: {len(users)}")
        print(f"   📁 Categorias: {len(categories)}")
        print(f"   📦 Produtos: {len(products)}")
        print(f"   🛍️  Pedidos: {len(orders)}")
        
        print("\n🔐 Credenciais de Acesso:")
        print("   Admin:")
        print("     Email: admin@dropshipping.com")
        print("     Senha: admin123")
        print("\n   Cliente:")
        print("     Email: joao@email.com")
        print("     Senha: cliente123")
        
    except Exception as e:
        print(f"❌ Erro ao popular banco: {str(e)}")
        raise
    
    finally:
        client.close()


if __name__ == "__main__":
    asyncio.run(seed_database())
