"""
Serviço de Rastreio Automático
- Integração com Correios
- Melhor Rastreio
- Rastreio.net
- Atualização automática de status
"""
import os
import httpx
import asyncio
from typing import Dict, List, Optional
from datetime import datetime, timezone
import logging

logger = logging.getLogger(__name__)


class TrackingService:
    """Serviço de rastreio automático de pedidos"""
    
    def __init__(self, db):
        self.db = db
        self.correios_user = os.getenv('CORREIOS_API_USER')
        self.correios_password = os.getenv('CORREIOS_API_PASSWORD')
        self.melhorrastreio_key = os.getenv('MELHORRASTREIO_API_KEY')
    
    async def track_order(self, order_id: str) -> Dict:
        """Rastreia um pedido específico"""
        try:
            order = await self.db.orders.find_one({'id': order_id})
            
            if not order:
                return {'success': False, 'error': 'Pedido não encontrado'}
            
            tracking_code = order.get('tracking_code')
            
            if not tracking_code:
                return {
                    'success': False, 
                    'error': 'Código de rastreio não disponível',
                    'order_status': order.get('status')
                }
            
            # Determina o tipo de rastreio baseado no código
            tracking_type = self._detect_tracking_type(tracking_code)
            
            if tracking_type == 'correios':
                tracking_data = await self._track_correios(tracking_code)
            elif tracking_type == 'china_post':
                tracking_data = await self._track_china_post(tracking_code)
            else:
                tracking_data = await self._track_generic(tracking_code)
            
            # Atualiza status do pedido baseado no rastreio
            if tracking_data.get('success'):
                await self._update_order_status(order_id, tracking_data)
            
            return {
                'success': True,
                'order_id': order_id,
                'tracking_code': tracking_code,
                'tracking_type': tracking_type,
                'current_status': tracking_data.get('current_status'),
                'events': tracking_data.get('events', []),
                'estimated_delivery': tracking_data.get('estimated_delivery')
            }
            
        except Exception as e:
            logger.error(f"Erro ao rastrear pedido {order_id}: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    def _detect_tracking_type(self, tracking_code: str) -> str:
        """Detecta o tipo de rastreio pelo formato do código"""
        if len(tracking_code) == 13 and tracking_code[:2].isalpha() and tracking_code[-2:].isalpha():
            return 'correios'  # Ex: AA123456789BR
        elif tracking_code.startswith('LP'):
            return 'china_post'
        else:
            return 'generic'
    
    async def _track_correios(self, tracking_code: str) -> Dict:
        """Rastreia via API dos Correios"""
        try:
            async with httpx.AsyncClient() as client:
                # API dos Correios
                url = "https://proxyapp.correios.com.br/v1/sro-rastro"
                
                headers = {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                }
                
                # Por enquanto, retorna dados simulados
                # Em produção, usar credenciais reais e fazer chamada à API
                
                # response = await client.get(
                #     url,
                #     headers=headers,
                #     params={'objetos': tracking_code}
                # )
                # data = response.json()
                
                # Dados simulados para teste
                data = {
                    'objetos': [{
                        'codObjeto': tracking_code,
                        'eventos': [
                            {
                                'tipo': 'BDE',
                                'status': '01',
                                'data': '15/01/2026',
                                'hora': '10:30',
                                'descricao': 'Objeto entregue ao destinatário',
                                'unidade': {
                                    'endereco': {
                                        'cidade': 'São Paulo',
                                        'uf': 'SP'
                                    }
                                }
                            },
                            {
                                'tipo': 'OEC',
                                'status': '01',
                                'data': '14/01/2026',
                                'hora': '08:15',
                                'descricao': 'Objeto saiu para entrega',
                                'unidade': {
                                    'endereco': {
                                        'cidade': 'São Paulo',
                                        'uf': 'SP'
                                    }
                                }
                            },
                            {
                                'tipo': 'DO',
                                'status': '01',
                                'data': '13/01/2026',
                                'hora': '14:20',
                                'descricao': 'Objeto postado',
                                'unidade': {
                                    'endereco': {
                                        'cidade': 'Campinas',
                                        'uf': 'SP'
                                    }
                                }
                            }
                        ]
                    }]
                }
                
                if data and 'objetos' in data and len(data['objetos']) > 0:
                    objeto = data['objetos'][0]
                    eventos = objeto.get('eventos', [])
                    
                    # Último evento é o status atual
                    current_event = eventos[0] if eventos else {}
                    
                    return {
                        'success': True,
                        'current_status': current_event.get('descricao', 'Status desconhecido'),
                        'current_status_code': current_event.get('tipo'),
                        'events': [
                            {
                                'date': evt.get('data'),
                                'time': evt.get('hora'),
                                'description': evt.get('descricao'),
                                'location': f"{evt.get('unidade', {}).get('endereco', {}).get('cidade', '')}, {evt.get('unidade', {}).get('endereco', {}).get('uf', '')}"
                            }
                            for evt in eventos
                        ],
                        'is_delivered': current_event.get('tipo') == 'BDE'
                    }
                
                return {'success': False, 'error': 'Nenhum evento de rastreio encontrado'}
                
        except Exception as e:
            logger.error(f"Erro ao rastrear Correios {tracking_code}: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    async def _track_china_post(self, tracking_code: str) -> Dict:
        """Rastreia via API do China Post / Melhor Rastreio"""
        try:
            async with httpx.AsyncClient() as client:
                # Usa API Melhor Rastreio para rastreio internacional
                url = f"https://api.melhorrastreio.com.br/api/v1/track/{tracking_code}"
                
                headers = {
                    'Authorization': f'Bearer {self.melhorrastreio_key}',
                    'Accept': 'application/json'
                }
                
                # Por enquanto, retorna dados simulados
                # Em produção: response = await client.get(url, headers=headers)
                
                # Dados simulados
                data = {
                    'tracking': {
                        'code': tracking_code,
                        'events': [
                            {
                                'date': '2026-02-10 18:00',
                                'status': 'Em trânsito para o Brasil',
                                'location': 'China'
                            },
                            {
                                'date': '2026-02-08 12:30',
                                'status': 'Postado',
                                'location': 'Guangzhou, China'
                            }
                        ],
                        'delivered': False,
                        'estimated_delivery': '2026-02-25'
                    }
                }
                
                if data and 'tracking' in data:
                    tracking = data['tracking']
                    events = tracking.get('events', [])
                    
                    return {
                        'success': True,
                        'current_status': events[0]['status'] if events else 'Sem atualizações',
                        'events': [
                            {
                                'date': evt.get('date'),
                                'description': evt.get('status'),
                                'location': evt.get('location')
                            }
                            for evt in events
                        ],
                        'is_delivered': tracking.get('delivered', False),
                        'estimated_delivery': tracking.get('estimated_delivery')
                    }
                
                return {'success': False, 'error': 'Rastreio não encontrado'}
                
        except Exception as e:
            logger.error(f"Erro ao rastrear China Post {tracking_code}: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    async def _track_generic(self, tracking_code: str) -> Dict:
        """Rastreio genérico via Melhor Rastreio"""
        try:
            # Usa Melhor Rastreio que suporta múltiplas transportadoras
            async with httpx.AsyncClient() as client:
                url = f"https://api.melhorrastreio.com.br/api/v1/track/{tracking_code}"
                
                headers = {
                    'Authorization': f'Bearer {self.melhorrastreio_key}',
                    'Accept': 'application/json'
                }
                
                # Dados simulados
                return {
                    'success': True,
                    'current_status': 'Em processamento',
                    'events': [
                        {
                            'date': '2026-02-12',
                            'description': 'Pedido em processamento',
                            'location': 'Centro de Distribuição'
                        }
                    ],
                    'is_delivered': False
                }
                
        except Exception as e:
            logger.error(f"Erro no rastreio genérico {tracking_code}: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    async def _update_order_status(self, order_id: str, tracking_data: Dict):
        """Atualiza status do pedido baseado nos dados de rastreio"""
        try:
            current_status = tracking_data.get('current_status', '')
            is_delivered = tracking_data.get('is_delivered', False)
            
            # Mapeia status do rastreio para status do pedido
            order_status = 'processing'
            
            if is_delivered:
                order_status = 'delivered'
            elif 'saiu para entrega' in current_status.lower():
                order_status = 'shipped'
            elif 'postado' in current_status.lower() or 'em trânsito' in current_status.lower():
                order_status = 'shipped'
            
            # Atualiza pedido
            await self.db.orders.update_one(
                {'id': order_id},
                {
                    '$set': {
                        'status': order_status,
                        'tracking_last_update': datetime.now(timezone.utc),
                        'tracking_events': tracking_data.get('events', [])
                    }
                }
            )
            
            logger.info(f"Pedido {order_id} atualizado para status: {order_status}")
            
        except Exception as e:
            logger.error(f"Erro ao atualizar status do pedido {order_id}: {str(e)}")
    
    async def track_all_active_orders(self) -> Dict:
        """Rastreia todos os pedidos ativos (não entregues)"""
        results = {
            'total_checked': 0,
            'updated': 0,
            'delivered': 0,
            'errors': []
        }
        
        try:
            # Busca pedidos que estão enviados mas não entregues
            orders = await self.db.orders.find({
                'status': {'$in': ['processing', 'shipped']},
                'tracking_code': {'$exists': True, '$ne': None}
            }).to_list(None)
            
            results['total_checked'] = len(orders)
            
            for order in orders:
                try:
                    tracking_result = await self.track_order(order['id'])
                    
                    if tracking_result.get('success'):
                        results['updated'] += 1
                        
                        if tracking_result.get('is_delivered'):
                            results['delivered'] += 1
                    
                except Exception as e:
                    results['errors'].append({
                        'order_id': order['id'],
                        'error': str(e)
                    })
            
            logger.info(
                f"Rastreio automático concluído: {results['updated']} pedidos atualizados, "
                f"{results['delivered']} entregues"
            )
            
            return results
            
        except Exception as e:
            logger.error(f"Erro no rastreio em massa: {str(e)}")
            results['errors'].append({'general': str(e)})
            return results
    
    async def add_tracking_code(self, order_id: str, tracking_code: str) -> Dict:
        """Adiciona código de rastreio a um pedido"""
        try:
            order = await self.db.orders.find_one({'id': order_id})
            
            if not order:
                return {'success': False, 'error': 'Pedido não encontrado'}
            
            # Atualiza pedido com código de rastreio
            await self.db.orders.update_one(
                {'id': order_id},
                {
                    '$set': {
                        'tracking_code': tracking_code,
                        'tracking_added_at': datetime.now(timezone.utc),
                        'status': 'shipped'
                    }
                }
            )
            
            # Faz rastreio inicial
            tracking_result = await self.track_order(order_id)
            
            logger.info(f"Código de rastreio {tracking_code} adicionado ao pedido {order_id}")
            
            return {
                'success': True,
                'order_id': order_id,
                'tracking_code': tracking_code,
                'initial_tracking': tracking_result
            }
            
        except Exception as e:
            logger.error(f"Erro ao adicionar código de rastreio: {str(e)}")
            return {'success': False, 'error': str(e)}
