"""
Serviço de Repricing Automático
- Atualização de preços baseada em câmbio
- Aplicação de margem configurável
- Cálculo de impostos
- Regras de precificação dinâmica
"""
import os
import httpx
import asyncio
from typing import Dict, List, Optional
from datetime import datetime, timezone
import logging

logger = logging.getLogger(__name__)


class RepricingService:
    """Serviço de repricing automático de produtos"""
    
    def __init__(self, db):
        self.db = db
        self.exchange_api_key = os.getenv('EXCHANGE_RATE_API_KEY')
        self.default_margin = float(os.getenv('DEFAULT_MARGIN_PERCENTAGE', '40'))
        self.default_exchange_rate = float(os.getenv('DEFAULT_EXCHANGE_RATE', '5.00'))
        
        # Alíquotas de impostos (SP)
        self.tax_rates = {
            'ii': 0.35,      # Imposto de Importação
            'ipi': 0.05,     # IPI
            'pis': 0.021,    # PIS
            'cofins': 0.0965,  # COFINS
            'icms': 0.18     # ICMS SP
        }
    
    async def get_current_exchange_rate(self) -> float:
        """Obtém taxa de câmbio atual USD/BRL"""
        try:
            async with httpx.AsyncClient() as client:
                # API gratuita de câmbio
                response = await client.get(
                    'https://api.exchangerate-api.com/v4/latest/USD'
                )
                data = response.json()
                rate = data['rates']['BRL']
                
                logger.info(f"Taxa de câmbio atualizada: USD 1.00 = BRL {rate:.2f}")
                return rate
                
        except Exception as e:
            logger.error(f"Erro ao buscar taxa de câmbio: {str(e)}")
            # Retorna taxa padrão se houver erro
            return self.default_exchange_rate
    
    async def calculate_import_costs(self, product_usd_price: float, exchange_rate: float) -> Dict:
        """Calcula custos de importação com impostos"""
        
        # CIF em BRL (Custo + Seguro + Frete)
        cif_brl = product_usd_price * exchange_rate
        
        # Cálculo de impostos
        ii = cif_brl * self.tax_rates['ii']
        ipi = (cif_brl + ii) * self.tax_rates['ipi']
        pis = (cif_brl + ii + ipi) * self.tax_rates['pis']
        cofins = (cif_brl + ii + ipi) * self.tax_rates['cofins']
        
        # Base de cálculo ICMS
        base_icms = cif_brl + ii + ipi + pis + cofins
        icms = base_icms * self.tax_rates['icms'] / (1 - self.tax_rates['icms'])
        
        total_taxes = ii + ipi + pis + cofins + icms
        total_cost = cif_brl + total_taxes
        
        return {
            'cif_brl': round(cif_brl, 2),
            'ii': round(ii, 2),
            'ipi': round(ipi, 2),
            'pis': round(pis, 2),
            'cofins': round(cofins, 2),
            'icms': round(icms, 2),
            'total_taxes': round(total_taxes, 2),
            'total_cost': round(total_cost, 2),
            'tax_percentage': round((total_taxes / cif_brl) * 100, 2)
        }
    
    async def calculate_final_price(
        self, 
        cost: float, 
        margin_percentage: Optional[float] = None
    ) -> float:
        """Calcula preço final com margem"""
        if margin_percentage is None:
            margin_percentage = self.default_margin
        
        # Preço final = Custo + Margem
        final_price = cost * (1 + margin_percentage / 100)
        
        return round(final_price, 2)
    
    async def update_product_pricing(self, product_id: str, exchange_rate: Optional[float] = None) -> Dict:
        """Atualiza precificação de um produto específico"""
        try:
            product = await self.db.products.find_one({'id': product_id})
            
            if not product:
                return {'success': False, 'error': 'Produto não encontrado'}
            
            # Obtém taxa de câmbio atual se não fornecida
            if exchange_rate is None:
                exchange_rate = await self.get_current_exchange_rate()
            
            # Determina preço base do fornecedor
            supplier = product.get('supplier')
            
            if supplier == 'aliexpress':
                # Produto em USD
                base_price_usd = product.get('supplier_price_usd', 0)
                
                if base_price_usd == 0:
                    return {'success': False, 'error': 'Preço do fornecedor não disponível'}
                
                # Calcula custos de importação
                import_costs = await self.calculate_import_costs(base_price_usd, exchange_rate)
                cost = import_costs['total_cost']
                
            else:
                # Fornecedor brasileiro (já em BRL)
                cost = product.get('supplier_price_brl', 0)
                import_costs = None
            
            # Margem personalizada ou padrão
            margin = product.get('margin_percentage', self.default_margin)
            
            # Calcula preço final
            final_price = await self.calculate_final_price(cost, margin)
            
            # Atualiza produto no banco
            update_data = {
                'price': final_price,
                'cost': cost,
                'margin_percentage': margin,
                'last_price_update': datetime.now(timezone.utc),
                'exchange_rate_used': exchange_rate
            }
            
            if import_costs:
                update_data['import_costs'] = import_costs
            
            await self.db.products.update_one(
                {'id': product_id},
                {'$set': update_data}
            )
            
            logger.info(f"Produto {product_id} reprecificado: R$ {final_price:.2f}")
            
            return {
                'success': True,
                'product_id': product_id,
                'old_price': product.get('price', 0),
                'new_price': final_price,
                'cost': cost,
                'margin': margin,
                'exchange_rate': exchange_rate
            }
            
        except Exception as e:
            logger.error(f"Erro ao atualizar preço do produto {product_id}: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    async def reprice_all_products(self) -> Dict:
        """Reprecia todos os produtos do catálogo"""
        results = {
            'total_products': 0,
            'updated': 0,
            'failed': 0,
            'errors': []
        }
        
        try:
            # Obtém taxa de câmbio atual
            exchange_rate = await self.get_current_exchange_rate()
            
            # Busca todos os produtos ativos
            products = await self.db.products.find({'is_available': True}).to_list(None)
            results['total_products'] = len(products)
            
            # Atualiza cada produto
            for product in products:
                try:
                    result = await self.update_product_pricing(
                        product['id'], 
                        exchange_rate
                    )
                    
                    if result['success']:
                        results['updated'] += 1
                    else:
                        results['failed'] += 1
                        results['errors'].append({
                            'product_id': product['id'],
                            'error': result.get('error')
                        })
                        
                except Exception as e:
                    results['failed'] += 1
                    results['errors'].append({
                        'product_id': product['id'],
                        'error': str(e)
                    })
            
            logger.info(
                f"Repricing concluído: {results['updated']} atualizados, "
                f"{results['failed']} falhas de {results['total_products']} produtos"
            )
            
            return results
            
        except Exception as e:
            logger.error(f"Erro no repricing geral: {str(e)}")
            results['errors'].append({'general': str(e)})
            return results
    
    async def apply_pricing_rules(self, product_id: str, rules: Dict) -> Dict:
        """Aplica regras de precificação personalizadas"""
        try:
            product = await self.db.products.find_one({'id': product_id})
            
            if not product:
                return {'success': False, 'error': 'Produto não encontrado'}
            
            # Regras possíveis:
            # - margin_percentage: margem específica
            # - min_price: preço mínimo
            # - max_price: preço máximo
            # - competitor_price: ajuste baseado em concorrente
            # - discount_percentage: desconto temporário
            
            update_data = {}
            
            if 'margin_percentage' in rules:
                update_data['margin_percentage'] = rules['margin_percentage']
            
            if 'min_price' in rules:
                update_data['min_price'] = rules['min_price']
            
            if 'max_price' in rules:
                update_data['max_price'] = rules['max_price']
            
            if 'discount_percentage' in rules:
                original_price = product.get('price', 0)
                discount = rules['discount_percentage']
                discounted_price = original_price * (1 - discount / 100)
                
                update_data['discounted_price'] = round(discounted_price, 2)
                update_data['discount_percentage'] = discount
                update_data['discount_ends_at'] = rules.get('discount_ends_at')
            
            # Atualiza regras no produto
            await self.db.products.update_one(
                {'id': product_id},
                {'$set': update_data}
            )
            
            # Recalcula preço com novas regras
            result = await self.update_product_pricing(product_id)
            
            return {
                'success': True,
                'product_id': product_id,
                'rules_applied': update_data,
                'new_pricing': result
            }
            
        except Exception as e:
            logger.error(f"Erro ao aplicar regras de pricing: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    async def bulk_discount(self, category: str, discount_percentage: float, duration_days: int) -> Dict:
        """Aplica desconto em massa por categoria"""
        try:
            from datetime import timedelta
            
            # Busca produtos da categoria
            products = await self.db.products.find({'category': category}).to_list(None)
            
            discount_ends_at = datetime.now(timezone.utc) + timedelta(days=duration_days)
            
            updated_count = 0
            
            for product in products:
                original_price = product.get('price', 0)
                discounted_price = original_price * (1 - discount_percentage / 100)
                
                await self.db.products.update_one(
                    {'id': product['id']},
                    {
                        '$set': {
                            'discounted_price': round(discounted_price, 2),
                            'discount_percentage': discount_percentage,
                            'discount_ends_at': discount_ends_at
                        }
                    }
                )
                
                updated_count += 1
            
            logger.info(f"Desconto de {discount_percentage}% aplicado em {updated_count} produtos da categoria {category}")
            
            return {
                'success': True,
                'category': category,
                'products_updated': updated_count,
                'discount_percentage': discount_percentage,
                'ends_at': discount_ends_at
            }
            
        except Exception as e:
            logger.error(f"Erro ao aplicar desconto em massa: {str(e)}")
            return {'success': False, 'error': str(e)}
