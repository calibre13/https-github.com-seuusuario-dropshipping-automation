"""
Serviço de Notificações Automáticas
- Email (SMTP)
- WhatsApp (Twilio)
- Templates de mensagens
- Gatilhos automáticos por status de pedido
"""
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from twilio.rest import Client
from typing import Dict, Optional, List
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class NotificationService:
    """Serviço de notificações automáticas"""
    
    def __init__(self, db):
        self.db = db
        
        # Configuração SMTP
        self.smtp_host = os.getenv('SMTP_HOST')
        self.smtp_port = int(os.getenv('SMTP_PORT', '587'))
        self.smtp_user = os.getenv('SMTP_USER')
        self.smtp_password = os.getenv('SMTP_PASSWORD')
        self.email_from = os.getenv('EMAIL_FROM')
        
        # Configuração Twilio WhatsApp
        self.twilio_sid = os.getenv('TWILIO_ACCOUNT_SID')
        self.twilio_token = os.getenv('TWILIO_AUTH_TOKEN')
        self.whatsapp_number = os.getenv('TWILIO_WHATSAPP_NUMBER')
        
        # Cliente Twilio
        if self.twilio_sid and self.twilio_token:
            self.twilio_client = Client(self.twilio_sid, self.twilio_token)
        else:
            self.twilio_client = None
    
    # ==================== TEMPLATES DE EMAIL ====================
    
    def _get_email_template(self, template_type: str, data: Dict) -> Dict[str, str]:
        """Retorna template de email baseado no tipo"""
        
        templates = {
            'order_confirmed': {
                'subject': f'Pedido #{data["order_number"]} Confirmado! 🎉',
                'body': f"""
                <html>
                <body style="font-family: Arial, sans-serif; padding: 20px;">
                    <h2 style="color: #4CAF50;">Pedido Confirmado!</h2>
                    <p>Olá {data['customer_name']},</p>
                    <p>Seu pedido <strong>#{data['order_number']}</strong> foi confirmado com sucesso!</p>
                    
                    <div style="background-color: #f5f5f5; padding: 15px; margin: 20px 0; border-radius: 5px;">
                        <h3>Resumo do Pedido:</h3>
                        <p><strong>Valor Total:</strong> R$ {data['total']:.2f}</p>
                        <p><strong>Forma de Pagamento:</strong> {data['payment_method']}</p>
                        <p><strong>Data:</strong> {data['order_date']}</p>
                    </div>
                    
                    <p>Em breve você receberá o código de rastreio.</p>
                    <p>Obrigado pela preferência! 💚💛</p>
                    
                    <hr style="margin: 30px 0;">
                    <p style="font-size: 12px; color: #666;">
                        Qualquer dúvida, responda este email.
                    </p>
                </body>
                </html>
                """
            },
            
            'tracking_available': {
                'subject': f'Seu pedido foi enviado! 📦 Código: {data["tracking_code"]}',
                'body': f"""
                <html>
                <body style="font-family: Arial, sans-serif; padding: 20px;">
                    <h2 style="color: #2196F3;">Pedido Enviado! 📦</h2>
                    <p>Olá {data['customer_name']},</p>
                    <p>Boa notícia! Seu pedido <strong>#{data['order_number']}</strong> foi postado!</p>
                    
                    <div style="background-color: #e3f2fd; padding: 20px; margin: 20px 0; border-radius: 5px; text-align: center;">
                        <h3>Código de Rastreio:</h3>
                        <p style="font-size: 24px; font-weight: bold; color: #1976D2;">{data['tracking_code']}</p>
                        <a href="https://rastreamento.correios.com.br/app/index.php?codigo={data['tracking_code']}" 
                           style="display: inline-block; background-color: #2196F3; color: white; padding: 12px 24px; text-decoration: none; border-radius: 5px; margin-top: 10px;">
                            Rastrear Pedido
                        </a>
                    </div>
                    
                    <p><strong>Previsão de Entrega:</strong> {data.get('estimated_delivery', '7-15 dias úteis')}</p>
                    <p>Acompanhe seu pedido e fique de olho na entrega! 👀</p>
                    
                    <hr style="margin: 30px 0;">
                    <p style="font-size: 12px; color: #666;">
                        Você receberá atualizações automáticas sobre o status da entrega.
                    </p>
                </body>
                </html>
                """
            },
            
            'out_for_delivery': {
                'subject': f'Seu pedido está saindo para entrega hoje! 🚚',
                'body': f"""
                <html>
                <body style="font-family: Arial, sans-serif; padding: 20px;">
                    <h2 style="color: #FF9800;">Saiu para Entrega! 🚚</h2>
                    <p>Olá {data['customer_name']},</p>
                    <p>Seu pedido <strong>#{data['order_number']}</strong> está a caminho!</p>
                    
                    <div style="background-color: #fff3e0; padding: 15px; margin: 20px 0; border-radius: 5px;">
                        <p style="font-size: 18px;">📍 <strong>O entregador está indo até você!</strong></p>
                        <p>Fique atento ao interfone/telefone.</p>
                    </div>
                    
                    <p><strong>Código de Rastreio:</strong> {data['tracking_code']}</p>
                    <p>Previsão de entrega: <strong>HOJE</strong></p>
                    
                    <hr style="margin: 30px 0;">
                    <p style="font-size: 12px; color: #666;">
                        Prepare-se para receber seu pedido! 🎁
                    </p>
                </body>
                </html>
                """
            },
            
            'delivered': {
                'subject': f'Pedido #{data["order_number"]} Entregue! 🎉',
                'body': f"""
                <html>
                <body style="font-family: Arial, sans-serif; padding: 20px;">
                    <h2 style="color: #4CAF50;">Pedido Entregue! 🎉</h2>
                    <p>Olá {data['customer_name']},</p>
                    <p>Seu pedido <strong>#{data['order_number']}</strong> foi entregue com sucesso!</p>
                    
                    <div style="background-color: #e8f5e9; padding: 15px; margin: 20px 0; border-radius: 5px; text-align: center;">
                        <p style="font-size: 20px;">✅ <strong>ENTREGUE</strong></p>
                        <p>Data da Entrega: {data['delivery_date']}</p>
                    </div>
                    
                    <p>Esperamos que você esteja satisfeito com sua compra!</p>
                    <p>Se tiver qualquer problema, entre em contato conosco.</p>
                    
                    <hr style="margin: 30px 0;">
                    <p style="font-size: 14px;">
                        ⭐ <strong>Gostou da experiência?</strong> Deixe uma avaliação!
                    </p>
                </body>
                </html>
                """
            }
        }
        
        return templates.get(template_type, {
            'subject': 'Atualização do seu pedido',
            'body': f'<p>Olá {data.get("customer_name", "Cliente")}, seu pedido foi atualizado.</p>'
        })
    
    # ==================== TEMPLATES DE WHATSAPP ====================
    
    def _get_whatsapp_template(self, template_type: str, data: Dict) -> str:
        """Retorna template de WhatsApp baseado no tipo"""
        
        templates = {
            'order_confirmed': f"""
🎉 *Pedido Confirmado!*

Olá {data['customer_name']}!

Seu pedido *#{data['order_number']}* foi confirmado.

💰 Valor: R$ {data['total']:.2f}
💳 Pagamento: {data['payment_method']}

Em breve você receberá o código de rastreio.

Obrigado pela preferência! 💚💛
            """,
            
            'tracking_available': f"""
📦 *Pedido Enviado!*

Olá {data['customer_name']}!

Seu pedido *#{data['order_number']}* foi postado!

📋 *Código de Rastreio:*
`{data['tracking_code']}`

Rastreie em: https://rastreamento.correios.com.br

📅 Previsão: {data.get('estimated_delivery', '7-15 dias úteis')}

Acompanhe seu pedido! 👀
            """,
            
            'out_for_delivery': f"""
🚚 *Saiu para Entrega!*

Olá {data['customer_name']}!

Seu pedido *#{data['order_number']}* está a caminho!

📍 O entregador está indo até você!
Fique atento ao interfone/telefone.

Previsão: *HOJE*

Prepare-se para receber! 🎁
            """,
            
            'delivered': f"""
✅ *Pedido Entregue!*

Olá {data['customer_name']}!

Seu pedido *#{data['order_number']}* foi entregue!

📅 Entrega: {data['delivery_date']}

Esperamos que goste da sua compra! 💚

Qualquer problema, estamos à disposição.

⭐ Gostou? Deixe uma avaliação!
            """
        }
        
        return templates.get(template_type, f"Atualização do pedido #{data.get('order_number', 'N/A')}")
    
    # ==================== ENVIO DE NOTIFICAÇÕES ====================
    
    async def send_email(self, to_email: str, subject: str, html_body: str) -> Dict:
        """Envia email"""
        try:
            msg = MIMEMultipart('alternative')
            msg['From'] = self.email_from
            msg['To'] = to_email
            msg['Subject'] = subject
            
            html_part = MIMEText(html_body, 'html', 'utf-8')
            msg.attach(html_part)
            
            # Conecta ao servidor SMTP
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls()
                server.login(self.smtp_user, self.smtp_password)
                server.send_message(msg)
            
            logger.info(f"Email enviado para {to_email}: {subject}")
            
            return {'success': True, 'to': to_email, 'subject': subject}
            
        except Exception as e:
            logger.error(f"Erro ao enviar email para {to_email}: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    async def send_whatsapp(self, to_number: str, message: str) -> Dict:
        """Envia mensagem WhatsApp via Twilio"""
        try:
            if not self.twilio_client:
                return {'success': False, 'error': 'Twilio não configurado'}
            
            # Formata número (deve começar com whatsapp:+55)
            if not to_number.startswith('whatsapp:'):
                to_number = f'whatsapp:+55{to_number.replace(" ", "").replace("-", "")}'
            
            message_obj = self.twilio_client.messages.create(
                from_=self.whatsapp_number,
                body=message,
                to=to_number
            )
            
            logger.info(f"WhatsApp enviado para {to_number}: SID {message_obj.sid}")
            
            return {'success': True, 'to': to_number, 'sid': message_obj.sid}
            
        except Exception as e:
            logger.error(f"Erro ao enviar WhatsApp para {to_number}: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    # ==================== NOTIFICAÇÕES AUTOMÁTICAS POR STATUS ====================
    
    async def notify_order_status(self, order_id: str, status: str) -> Dict:
        """Envia notificações baseadas no status do pedido"""
        try:
            order = await self.db.orders.find_one({'id': order_id})
            
            if not order:
                return {'success': False, 'error': 'Pedido não encontrado'}
            
            user = await self.db.users.find_one({'id': order['user_id']})
            
            if not user:
                return {'success': False, 'error': 'Usuário não encontrado'}
            
            # Mapeia status para tipo de template
            template_mapping = {
                'pending': 'order_confirmed',
                'processing': 'order_confirmed',
                'shipped': 'tracking_available',
                'out_for_delivery': 'out_for_delivery',
                'delivered': 'delivered'
            }
            
            template_type = template_mapping.get(status)
            
            if not template_type:
                return {'success': False, 'error': f'Template não encontrado para status: {status}'}
            
            # Prepara dados para os templates
            notification_data = {
                'customer_name': user.get('name', 'Cliente'),
                'order_number': order.get('order_number', order['id'][:8]),
                'total': order.get('total', 0),
                'payment_method': order.get('payment_method', 'N/A'),
                'order_date': order.get('created_at', datetime.now()).strftime('%d/%m/%Y'),
                'tracking_code': order.get('tracking_code', 'Em processamento'),
                'estimated_delivery': order.get('estimated_delivery', '7-15 dias úteis'),
                'delivery_date': datetime.now().strftime('%d/%m/%Y %H:%M')
            }
            
            results = {'email': None, 'whatsapp': None}
            
            # Envia Email
            if user.get('email'):
                email_template = self._get_email_template(template_type, notification_data)
                email_result = await self.send_email(
                    user['email'],
                    email_template['subject'],
                    email_template['body']
                )
                results['email'] = email_result
            
            # Envia WhatsApp
            if user.get('phone'):
                whatsapp_message = self._get_whatsapp_template(template_type, notification_data)
                whatsapp_result = await self.send_whatsapp(
                    user['phone'],
                    whatsapp_message
                )
                results['whatsapp'] = whatsapp_result
            
            # Registra notificação no pedido
            await self.db.orders.update_one(
                {'id': order_id},
                {
                    '$push': {
                        'notifications': {
                            'type': template_type,
                            'sent_at': datetime.now(),
                            'email_sent': results['email'].get('success') if results['email'] else False,
                            'whatsapp_sent': results['whatsapp'].get('success') if results['whatsapp'] else False
                        }
                    }
                }
            )
            
            return {
                'success': True,
                'order_id': order_id,
                'status': status,
                'notifications_sent': results
            }
            
        except Exception as e:
            logger.error(f"Erro ao notificar status do pedido {order_id}: {str(e)}")
            return {'success': False, 'error': str(e)}
    
    async def send_bulk_notification(self, customer_segment: str, subject: str, message: str) -> Dict:
        """Envia notificação em massa para segmento de clientes"""
        try:
            # Define filtro baseado no segmento
            if customer_segment == 'all':
                user_filter = {}
            elif customer_segment == 'vip':
                # Clientes com mais de 3 pedidos
                user_filter = {}  # Implementar lógica de VIP
            else:
                user_filter = {}
            
            users = await self.db.users.find(user_filter).to_list(None)
            
            results = {
                'total_users': len(users),
                'emails_sent': 0,
                'whatsapp_sent': 0,
                'errors': []
            }
            
            for user in users:
                try:
                    # Email
                    if user.get('email'):
                        email_result = await self.send_email(
                            user['email'],
                            subject,
                            f'<html><body><p>{message}</p></body></html>'
                        )
                        if email_result.get('success'):
                            results['emails_sent'] += 1
                    
                    # WhatsApp
                    if user.get('phone'):
                        whatsapp_result = await self.send_whatsapp(
                            user['phone'],
                            message
                        )
                        if whatsapp_result.get('success'):
                            results['whatsapp_sent'] += 1
                
                except Exception as e:
                    results['errors'].append({
                        'user_id': user['id'],
                        'error': str(e)
                    })
            
            logger.info(
                f"Notificação em massa: {results['emails_sent']} emails, "
                f"{results['whatsapp_sent']} WhatsApp enviados"
            )
            
            return results
            
        except Exception as e:
            logger.error(f"Erro no envio em massa: {str(e)}")
            return {'success': False, 'error': str(e)}
