"""
API Principal de Automação de Dropshipping
FastAPI + MongoDB + Automações Completas
"""
from fastapi import FastAPI, APIRouter, HTTPException, Depends, status, BackgroundTasks
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
from contextlib import asynccontextmanager
from dotenv import load_dotenv
from pydantic import BaseModel, Field, ConfigDict, EmailStr
from typing import List, Optional, Dict, Any
from enum import Enum
from datetime import datetime, timezone, timedelta
import os
import logging
import uuid
import bcrypt
import jwt

# Importa serviços de automação
import sys
sys.path.append(os.path.dirname(__file__))

from services.supplier_sync import SupplierSyncService
from services.repricing import RepricingService
from services.tracking import TrackingService
from services.notifications import NotificationService
from tasks.automation_tasks import AutomationTasks

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Carrega variáveis de ambiente
load_dotenv()

# Configuração MongoDB
MONGO_URL = os.getenv('MONGO_URL', 'mongodb://localhost:27017')
DB_NAME = os.getenv('DB_NAME', 'dropshipping_automation')

# Configuração JWT
JWT_SECRET = os.getenv('JWT_SECRET', 'your-secret-key-change-in-production')
JWT_ALGORITHM = 'HS256'
JWT_EXPIRATION_HOURS = 24

# Variáveis globais para serviços
db_client = None
db = None
automation_tasks = None


# ==================== LIFECYCLE EVENTS ====================

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Gerencia lifecycle da aplicação"""
    global db_client, db, automation_tasks
    
    # Startup
    logger.info("🚀 Iniciando aplicação...")
    
    try:
        # Conecta ao MongoDB
        db_client = AsyncIOMotorClient(MONGO_URL)
        db = db_client[DB_NAME]
        logger.info("✓ MongoDB conectado")
        
        # Inicializa serviços de automação
        supplier_sync = SupplierSyncService(db)
        repricing = RepricingService(db)
        tracking = TrackingService(db)
        notifications = NotificationService(db)
        
        # Inicializa sistema de tarefas automáticas
        automation_tasks = AutomationTasks(
            db,
            supplier_sync,
            repricing,
            tracking,
            notifications
        )
        automation_tasks.start()
        logger.info("✓ Sistema de automação iniciado")
        
        # Cria índices no MongoDB
        await create_indexes(db)
        logger.info("✓ Índices MongoDB criados")
        
        logger.info("🎉 Aplicação pronta!")
        
    except Exception as e:
        logger.error(f"❌ Erro ao iniciar aplicação: {str(e)}")
        raise
    
    yield
    
    # Shutdown
    logger.info("Encerrando aplicação...")
    
    if automation_tasks:
        automation_tasks.stop()
        logger.info("✓ Automações paradas")
    
    if db_client:
        db_client.close()
        logger.info("✓ MongoDB desconectado")
    
    logger.info("👋 Aplicação encerrada")


async def create_indexes(db):
    """Cria índices otimizados no MongoDB"""
    try:
        # Índices de usuários
        await db.users.create_index('email', unique=True)
        await db.users.create_index('role')
        
        # Índices de produtos
        await db.products.create_index('supplier')
        await db.products.create_index('supplier_sku')
        await db.products.create_index('category')
        await db.products.create_index('is_available')
        
        # Índices de pedidos
        await db.orders.create_index('user_id')
        await db.orders.create_index('status')
        await db.orders.create_index('tracking_code')
        await db.orders.create_index('created_at')
        
        # Índices de carrinhos
        await db.carts.create_index('user_id', unique=True)
        
        # Índices de logs
        await db.automation_logs.create_index('timestamp')
        await db.automation_logs.create_index('task')
        
    except Exception as e:
        logger.error(f"Erro ao criar índices: {str(e)}")


# ==================== APP INITIALIZATION ====================

app = FastAPI(
    title="Dropshipping Automation API",
    description="Sistema completo de automação de dropshipping",
    version="1.0.0",
    lifespan=lifespan
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Router com prefixo /api
api_router = APIRouter(prefix="/api")

# Security
security = HTTPBearer()


# ==================== ENUMS ====================

class UserRole(str, Enum):
    CLIENT = "client"
    ADMIN = "admin"


class OrderStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    SHIPPED = "shipped"
    OUT_FOR_DELIVERY = "out_for_delivery"
    DELIVERED = "delivered"
    CANCELLED = "cancelled"


class PaymentMethod(str, Enum):
    PIX = "pix"
    MERCADO_PAGO = "mercado_pago"
    CREDIT_CARD = "credit_card"


class SupplierType(str, Enum):
    ALIEXPRESS = "aliexpress"
    DROPI = "dropi"
    BLING = "bling"
    TINY = "tiny"


# ==================== MODELS ====================

class User(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    email: EmailStr
    password_hash: str
    role: UserRole = UserRole.CLIENT
    phone: Optional[str] = None
    cpf: Optional[str] = None
    address: Optional[Dict] = None
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class UserRegister(BaseModel):
    name: str
    email: EmailStr
    password: str
    phone: Optional[str] = None


class UserLogin(BaseModel):
    email: EmailStr
    password: str


class UserProfile(BaseModel):
    id: str
    name: str
    email: EmailStr
    role: UserRole
    phone: Optional[str] = None
    cpf: Optional[str] = None
    address: Optional[Dict] = None
    created_at: datetime


class Product(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    description: str
    price: float
    cost: Optional[float] = None
    stock: int = 0
    is_available: bool = True
    category: str
    image_url: Optional[str] = None
    images: List[str] = []
    
    # Dados do fornecedor
    supplier: str
    supplier_sku: str
    supplier_price_usd: Optional[float] = None
    supplier_price_brl: Optional[float] = None
    
    # Automação
    last_sync: Optional[datetime] = None
    last_price_update: Optional[datetime] = None
    margin_percentage: float = 40.0
    exchange_rate_used: Optional[float] = None
    import_costs: Optional[Dict] = None
    
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


class Order(BaseModel):
    model_config = ConfigDict(extra="ignore")
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    user_id: str
    order_number: str
    items: List[Dict]
    total: float
    status: OrderStatus = OrderStatus.PENDING
    payment_method: PaymentMethod
    shipping_address: Dict
    
    # Rastreio
    tracking_code: Optional[str] = None
    tracking_last_update: Optional[datetime] = None
    tracking_events: List[Dict] = []
    estimated_delivery: Optional[str] = None
    
    # Notificações
    notifications: List[Dict] = []
    
    created_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    updated_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))


# ==================== AUTHENTICATION ====================

def hash_password(password: str) -> str:
    """Gera hash da senha"""
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt).decode('utf-8')


def verify_password(password: str, password_hash: str) -> bool:
    """Verifica senha"""
    return bcrypt.checkpw(password.encode('utf-8'), password_hash.encode('utf-8'))


def create_jwt_token(user_id: str, email: str, role: str) -> str:
    """Cria token JWT"""
    payload = {
        'user_id': user_id,
        'email': email,
        'role': role,
        'exp': datetime.now(timezone.utc) + timedelta(hours=JWT_EXPIRATION_HOURS)
    }
    return jwt.encode(payload, JWT_SECRET, algorithm=JWT_ALGORITHM)


async def get_current_user(credentials: HTTPAuthorizationCredentials = Depends(security)) -> Dict:
    """Obtém usuário atual do token"""
    try:
        token = credentials.credentials
        payload = jwt.decode(token, JWT_SECRET, algorithms=[JWT_ALGORITHM])
        
        user = await db.users.find_one({'id': payload['user_id']})
        
        if not user:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Usuário não encontrado"
            )
        
        return user
        
    except jwt.ExpiredSignatureError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token expirado"
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Token inválido"
        )


async def require_admin(current_user: Dict = Depends(get_current_user)) -> Dict:
    """Requer usuário admin"""
    if current_user.get('role') != UserRole.ADMIN.value:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Acesso negado"
        )
    return current_user


# ==================== ENDPOINTS DE AUTENTICAÇÃO ====================

@api_router.post("/auth/register")
async def register(user_data: UserRegister):
    """Registra novo usuário"""
    try:
        # Verifica se email já existe
        existing = await db.users.find_one({'email': user_data.email})
        if existing:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Email já cadastrado"
            )
        
        # Cria usuário
        user = User(
            name=user_data.name,
            email=user_data.email,
            password_hash=hash_password(user_data.password),
            phone=user_data.phone
        )
        
        await db.users.insert_one(user.model_dump())
        
        # Cria token
        token = create_jwt_token(user.id, user.email, user.role.value)
        
        return {
            'user': UserProfile(**user.model_dump()),
            'token': token
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro no registro: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao criar usuário"
        )


@api_router.post("/auth/login")
async def login(credentials: UserLogin):
    """Faz login"""
    try:
        user = await db.users.find_one({'email': credentials.email})
        
        if not user or not verify_password(credentials.password, user['password_hash']):
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Email ou senha incorretos"
            )
        
        token = create_jwt_token(user['id'], user['email'], user['role'])
        
        return {
            'user': UserProfile(**user),
            'token': token
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro no login: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao fazer login"
        )


@api_router.get("/auth/me")
async def get_me(current_user: Dict = Depends(get_current_user)):
    """Obtém perfil do usuário"""
    return UserProfile(**current_user)


# ==================== ENDPOINTS DE PRODUTOS ====================

@api_router.get("/products")
async def list_products(
    category: Optional[str] = None,
    supplier: Optional[str] = None,
    available_only: bool = True
):
    """Lista produtos"""
    try:
        filter_query = {}
        
        if category:
            filter_query['category'] = category
        
        if supplier:
            filter_query['supplier'] = supplier
        
        if available_only:
            filter_query['is_available'] = True
        
        products = await db.products.find(filter_query).to_list(None)
        
        return products
        
    except Exception as e:
        logger.error(f"Erro ao listar produtos: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao buscar produtos"
        )


@api_router.get("/products/{product_id}")
async def get_product(product_id: str):
    """Obtém detalhes de um produto"""
    try:
        product = await db.products.find_one({'id': product_id})
        
        if not product:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Produto não encontrado"
            )
        
        return product
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao buscar produto: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao buscar produto"
        )


# ==================== ENDPOINTS DE PEDIDOS ====================

@api_router.post("/orders")
async def create_order(
    order_data: Dict,
    background_tasks: BackgroundTasks,
    current_user: Dict = Depends(get_current_user)
):
    """Cria novo pedido"""
    try:
        # Gera número do pedido
        order_count = await db.orders.count_documents({})
        order_number = f"ORD{order_count + 1:06d}"
        
        # Cria pedido
        order = Order(
            user_id=current_user['id'],
            order_number=order_number,
            items=order_data['items'],
            total=order_data['total'],
            payment_method=order_data['payment_method'],
            shipping_address=order_data['shipping_address']
        )
        
        await db.orders.insert_one(order.model_dump())
        
        # Envia notificação em background
        background_tasks.add_task(
            send_order_notification,
            order.id,
            'pending'
        )
        
        return order.model_dump()
        
    except Exception as e:
        logger.error(f"Erro ao criar pedido: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao criar pedido"
        )


@api_router.get("/orders")
async def list_orders(current_user: Dict = Depends(get_current_user)):
    """Lista pedidos do usuário"""
    try:
        orders = await db.orders.find(
            {'user_id': current_user['id']}
        ).sort('created_at', -1).to_list(None)
        
        return orders
        
    except Exception as e:
        logger.error(f"Erro ao listar pedidos: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao buscar pedidos"
        )


@api_router.get("/orders/{order_id}")
async def get_order(order_id: str, current_user: Dict = Depends(get_current_user)):
    """Obtém detalhes do pedido"""
    try:
        order = await db.orders.find_one({'id': order_id})
        
        if not order:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Pedido não encontrado"
            )
        
        # Verifica permissão
        if order['user_id'] != current_user['id'] and current_user['role'] != 'admin':
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Acesso negado"
            )
        
        return order
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao buscar pedido: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao buscar pedido"
        )


@api_router.get("/orders/{order_id}/tracking")
async def track_order(order_id: str, current_user: Dict = Depends(get_current_user)):
    """Rastreia pedido"""
    try:
        tracking_service = TrackingService(db)
        result = await tracking_service.track_order(order_id)
        
        return result
        
    except Exception as e:
        logger.error(f"Erro ao rastrear pedido: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao rastrear pedido"
        )


# ==================== ENDPOINTS DE CARRINHO ====================

@api_router.get("/cart")
async def get_cart(current_user: Dict = Depends(get_current_user)):
    """Obtém carrinho do usuário"""
    try:
        cart = await db.carts.find_one({'user_id': current_user['id']})
        
        if not cart:
            cart = {
                'user_id': current_user['id'],
                'items': [],
                'total': 0
            }
            await db.carts.insert_one(cart)
        
        return cart
        
    except Exception as e:
        logger.error(f"Erro ao buscar carrinho: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao buscar carrinho"
        )


@api_router.post("/cart/add")
async def add_to_cart(
    item_data: Dict,
    current_user: Dict = Depends(get_current_user)
):
    """Adiciona item ao carrinho"""
    try:
        product_id = item_data['product_id']
        quantity = item_data.get('quantity', 1)
        
        # Busca produto
        product = await db.products.find_one({'id': product_id})
        
        if not product:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Produto não encontrado"
            )
        
        # Verifica estoque
        if product['stock'] < quantity:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Estoque insuficiente"
            )
        
        # Atualiza carrinho
        cart = await db.carts.find_one({'user_id': current_user['id']})
        
        if not cart:
            cart = {
                'user_id': current_user['id'],
                'items': [],
                'total': 0
            }
        
        # Adiciona ou atualiza item
        item_exists = False
        for item in cart['items']:
            if item['product_id'] == product_id:
                item['quantity'] += quantity
                item_exists = True
                break
        
        if not item_exists:
            cart['items'].append({
                'product_id': product_id,
                'name': product['name'],
                'price': product['price'],
                'quantity': quantity,
                'image_url': product.get('image_url')
            })
        
        # Recalcula total
        cart['total'] = sum(item['price'] * item['quantity'] for item in cart['items'])
        cart['updated_at'] = datetime.now(timezone.utc)
        
        await db.carts.update_one(
            {'user_id': current_user['id']},
            {'$set': cart},
            upsert=True
        )
        
        return cart
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Erro ao adicionar ao carrinho: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao adicionar ao carrinho"
        )


# ==================== ENDPOINTS DE AUTOMAÇÃO ====================

@api_router.post("/automation/sync", dependencies=[Depends(require_admin)])
async def trigger_sync(background_tasks: BackgroundTasks):
    """Dispara sincronização manual com fornecedores"""
    try:
        background_tasks.add_task(run_supplier_sync)
        
        return {
            'success': True,
            'message': 'Sincronização iniciada em background'
        }
        
    except Exception as e:
        logger.error(f"Erro ao disparar sync: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao iniciar sincronização"
        )


@api_router.post("/automation/repricing", dependencies=[Depends(require_admin)])
async def trigger_repricing(background_tasks: BackgroundTasks):
    """Dispara repricing manual"""
    try:
        background_tasks.add_task(run_repricing)
        
        return {
            'success': True,
            'message': 'Repricing iniciado em background'
        }
        
    except Exception as e:
        logger.error(f"Erro ao disparar repricing: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao iniciar repricing"
        )


@api_router.post("/automation/tracking", dependencies=[Depends(require_admin)])
async def trigger_tracking(background_tasks: BackgroundTasks):
    """Dispara rastreio manual"""
    try:
        background_tasks.add_task(run_tracking_update)
        
        return {
            'success': True,
            'message': 'Rastreio iniciado em background'
        }
        
    except Exception as e:
        logger.error(f"Erro ao disparar rastreio: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao iniciar rastreio"
        )


@api_router.get("/automation/stats", dependencies=[Depends(require_admin)])
async def get_automation_stats():
    """Obtém estatísticas de automação"""
    try:
        if automation_tasks:
            stats = automation_tasks.get_stats()
            
            # Adiciona logs recentes
            recent_logs = await db.automation_logs.find().sort(
                'timestamp', -1
            ).limit(10).to_list(None)
            
            stats['recent_logs'] = recent_logs
            
            return stats
        
        return {'error': 'Sistema de automação não inicializado'}
        
    except Exception as e:
        logger.error(f"Erro ao buscar stats: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao buscar estatísticas"
        )


# ==================== ENDPOINTS ADMIN ====================

@api_router.get("/admin/orders", dependencies=[Depends(require_admin)])
async def admin_list_orders(
    status: Optional[str] = None,
    limit: int = 50
):
    """Lista todos os pedidos (admin)"""
    try:
        filter_query = {}
        
        if status:
            filter_query['status'] = status
        
        orders = await db.orders.find(filter_query).sort(
            'created_at', -1
        ).limit(limit).to_list(None)
        
        return orders
        
    except Exception as e:
        logger.error(f"Erro ao listar pedidos admin: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao buscar pedidos"
        )


@api_router.put("/admin/orders/{order_id}/status", dependencies=[Depends(require_admin)])
async def update_order_status(
    order_id: str,
    status_data: Dict,
    background_tasks: BackgroundTasks
):
    """Atualiza status do pedido"""
    try:
        new_status = status_data['status']
        
        await db.orders.update_one(
            {'id': order_id},
            {
                '$set': {
                    'status': new_status,
                    'updated_at': datetime.now(timezone.utc)
                }
            }
        )
        
        # Envia notificação em background
        background_tasks.add_task(
            send_order_notification,
            order_id,
            new_status
        )
        
        return {'success': True, 'status': new_status}
        
    except Exception as e:
        logger.error(f"Erro ao atualizar status: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao atualizar status"
        )


@api_router.post("/admin/orders/{order_id}/tracking", dependencies=[Depends(require_admin)])
async def add_tracking_code(
    order_id: str,
    tracking_data: Dict,
    background_tasks: BackgroundTasks
):
    """Adiciona código de rastreio ao pedido"""
    try:
        tracking_code = tracking_data['tracking_code']
        
        tracking_service = TrackingService(db)
        result = await tracking_service.add_tracking_code(order_id, tracking_code)
        
        if result['success']:
            # Envia notificação
            background_tasks.add_task(
                send_order_notification,
                order_id,
                'shipped'
            )
        
        return result
        
    except Exception as e:
        logger.error(f"Erro ao adicionar rastreio: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao adicionar código de rastreio"
        )


@api_router.post("/admin/products", dependencies=[Depends(require_admin)])
async def create_product(product_data: Dict):
    """Cria novo produto"""
    try:
        product = Product(**product_data)
        await db.products.insert_one(product.model_dump())
        
        return product.model_dump()
        
    except Exception as e:
        logger.error(f"Erro ao criar produto: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao criar produto"
        )


@api_router.put("/admin/products/{product_id}", dependencies=[Depends(require_admin)])
async def update_product(product_id: str, product_data: Dict):
    """Atualiza produto"""
    try:
        product_data['updated_at'] = datetime.now(timezone.utc)
        
        await db.products.update_one(
            {'id': product_id},
            {'$set': product_data}
        )
        
        return {'success': True}
        
    except Exception as e:
        logger.error(f"Erro ao atualizar produto: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao atualizar produto"
        )


@api_router.get("/admin/dashboard", dependencies=[Depends(require_admin)])
async def get_dashboard():
    """Obtém dados do dashboard admin"""
    try:
        from datetime import timedelta
        
        today = datetime.now(timezone.utc)
        yesterday = today - timedelta(days=1)
        last_week = today - timedelta(days=7)
        
        # Estatísticas
        total_orders = await db.orders.count_documents({})
        orders_today = await db.orders.count_documents({
            'created_at': {'$gte': yesterday}
        })
        
        total_products = await db.products.count_documents({})
        active_products = await db.products.count_documents({'is_available': True})
        
        # Pedidos por status
        orders_by_status = {}
        for status in OrderStatus:
            count = await db.orders.count_documents({'status': status.value})
            orders_by_status[status.value] = count
        
        # Receita
        orders = await db.orders.find({}).to_list(None)
        total_revenue = sum(order.get('total', 0) for order in orders)
        
        orders_this_week = await db.orders.find({
            'created_at': {'$gte': last_week}
        }).to_list(None)
        revenue_this_week = sum(order.get('total', 0) for order in orders_this_week)
        
        return {
            'orders': {
                'total': total_orders,
                'today': orders_today,
                'by_status': orders_by_status
            },
            'products': {
                'total': total_products,
                'active': active_products
            },
            'revenue': {
                'total': total_revenue,
                'this_week': revenue_this_week
            },
            'automation': automation_tasks.get_stats() if automation_tasks else {}
        }
        
    except Exception as e:
        logger.error(f"Erro ao buscar dashboard: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao buscar dados do dashboard"
        )


# ==================== BACKGROUND TASKS ====================

async def run_supplier_sync():
    """Executa sincronização com fornecedores"""
    try:
        supplier_sync = SupplierSyncService(db)
        await supplier_sync.sync_all_suppliers()
    except Exception as e:
        logger.error(f"Erro na sincronização em background: {str(e)}")


async def run_repricing():
    """Executa repricing de produtos"""
    try:
        repricing = RepricingService(db)
        await repricing.reprice_all_products()
    except Exception as e:
        logger.error(f"Erro no repricing em background: {str(e)}")


async def run_tracking_update():
    """Executa atualização de rastreio"""
    try:
        tracking = TrackingService(db)
        await tracking.track_all_active_orders()
    except Exception as e:
        logger.error(f"Erro no rastreio em background: {str(e)}")


async def send_order_notification(order_id: str, status: str):
    """Envia notificação de pedido"""
    try:
        notifications = NotificationService(db)
        await notifications.notify_order_status(order_id, status)
    except Exception as e:
        logger.error(f"Erro ao enviar notificação: {str(e)}")


# ==================== MOUNT ROUTER ====================

app.include_router(api_router)


# ==================== ROOT ENDPOINT ====================

@app.get("/")
async def root():
    """Endpoint raiz"""
    return {
        'name': 'Dropshipping Automation API',
        'version': '1.0.0',
        'status': 'running',
        'automation_active': automation_tasks.scheduler.running if automation_tasks else False
    }


@app.get("/health")
async def health_check():
    """Health check"""
    try:
        # Testa conexão MongoDB
        await db.command('ping')
        
        return {
            'status': 'healthy',
            'database': 'connected',
            'automation': 'active' if automation_tasks and automation_tasks.scheduler.running else 'inactive'
        }
    except Exception as e:
        logger.error(f"Health check falhou: {str(e)}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Service unhealthy"
        )


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "server:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )
