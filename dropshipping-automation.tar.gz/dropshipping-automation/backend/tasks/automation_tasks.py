"""
Sistema de Tarefas Automáticas em Background
- Sincronização periódica de estoque
- Repricing automático
- Rastreio automático
- Notificações programadas
"""
import os
import logging
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.triggers.cron import CronTrigger
from datetime import datetime, timezone
from typing import Dict

logger = logging.getLogger(__name__)


class AutomationTasks:
    """Gerencia tarefas automáticas em background"""
    
    def __init__(self, db, supplier_sync_service, repricing_service, tracking_service, notification_service):
        self.db = db
        self.supplier_sync = supplier_sync_service
        self.repricing = repricing_service
        self.tracking = tracking_service
        self.notifications = notification_service
        
        # Configurações de intervalo
        self.sync_interval = int(os.getenv('AUTO_SYNC_INTERVAL_MINUTES', '30'))
        self.tracking_interval = int(os.getenv('AUTO_TRACKING_UPDATE_MINUTES', '60'))
        self.repricing_enabled = os.getenv('AUTO_REPRICING_ENABLED', 'true').lower() == 'true'
        self.notifications_enabled = os.getenv('AUTO_NOTIFICATIONS_ENABLED', 'true').lower() == 'true'
        
        # Scheduler
        self.scheduler = AsyncIOScheduler()
        
        # Estatísticas
        self.stats = {
            'last_sync': None,
            'last_repricing': None,
            'last_tracking': None,
            'total_syncs': 0,
            'total_repricings': 0,
            'total_trackings': 0
        }
    
    def start(self):
        """Inicia todas as tarefas automáticas"""
        logger.info("Iniciando sistema de automação...")
        
        # Tarefa 1: Sincronização de Estoque
        # Executa a cada X minutos
        self.scheduler.add_job(
            self.auto_sync_suppliers,
            trigger=IntervalTrigger(minutes=self.sync_interval),
            id='auto_sync_suppliers',
            name='Sincronização Automática de Estoque',
            replace_existing=True
        )
        logger.info(f"✓ Sincronização de estoque: a cada {self.sync_interval} minutos")
        
        # Tarefa 2: Repricing Automático
        # Executa diariamente às 00:00 e às 12:00
        if self.repricing_enabled:
            self.scheduler.add_job(
                self.auto_repricing,
                trigger=CronTrigger(hour='0,12', minute='0'),
                id='auto_repricing',
                name='Repricing Automático',
                replace_existing=True
            )
            logger.info("✓ Repricing automático: 2x ao dia (00:00 e 12:00)")
        
        # Tarefa 3: Rastreio Automático
        # Executa a cada X minutos
        self.scheduler.add_job(
            self.auto_tracking_update,
            trigger=IntervalTrigger(minutes=self.tracking_interval),
            id='auto_tracking',
            name='Atualização Automática de Rastreio',
            replace_existing=True
        )
        logger.info(f"✓ Rastreio automático: a cada {self.tracking_interval} minutos")
        
        # Tarefa 4: Limpeza de Carrinho Abandonado
        # Executa diariamente às 03:00
        self.scheduler.add_job(
            self.cleanup_abandoned_carts,
            trigger=CronTrigger(hour='3', minute='0'),
            id='cleanup_carts',
            name='Limpeza de Carrinhos Abandonados',
            replace_existing=True
        )
        logger.info("✓ Limpeza de carrinhos: diariamente às 03:00")
        
        # Tarefa 5: Relatório Diário
        # Executa diariamente às 08:00
        self.scheduler.add_job(
            self.daily_report,
            trigger=CronTrigger(hour='8', minute='0'),
            id='daily_report',
            name='Relatório Diário',
            replace_existing=True
        )
        logger.info("✓ Relatório diário: diariamente às 08:00")
        
        # Inicia o scheduler
        self.scheduler.start()
        logger.info("🚀 Sistema de automação iniciado com sucesso!")
    
    def stop(self):
        """Para todas as tarefas automáticas"""
        logger.info("Parando sistema de automação...")
        self.scheduler.shutdown()
        logger.info("Sistema de automação parado.")
    
    async def auto_sync_suppliers(self):
        """Tarefa: Sincronização automática com fornecedores"""
        try:
            logger.info("Iniciando sincronização automática de fornecedores...")
            
            results = await self.supplier_sync.sync_all_suppliers()
            
            self.stats['last_sync'] = datetime.now(timezone.utc)
            self.stats['total_syncs'] += 1
            
            # Registra log no banco
            await self.db.automation_logs.insert_one({
                'task': 'supplier_sync',
                'timestamp': datetime.now(timezone.utc),
                'results': results,
                'status': 'success' if results['total_products_updated'] > 0 else 'no_updates'
            })
            
            logger.info(
                f"Sincronização concluída: {results['total_products_updated']} produtos atualizados"
            )
            
        except Exception as e:
            logger.error(f"Erro na sincronização automática: {str(e)}")
            await self.db.automation_logs.insert_one({
                'task': 'supplier_sync',
                'timestamp': datetime.now(timezone.utc),
                'error': str(e),
                'status': 'error'
            })
    
    async def auto_repricing(self):
        """Tarefa: Repricing automático de produtos"""
        try:
            logger.info("Iniciando repricing automático...")
            
            results = await self.repricing.reprice_all_products()
            
            self.stats['last_repricing'] = datetime.now(timezone.utc)
            self.stats['total_repricings'] += 1
            
            # Registra log no banco
            await self.db.automation_logs.insert_one({
                'task': 'auto_repricing',
                'timestamp': datetime.now(timezone.utc),
                'results': results,
                'status': 'success' if results['updated'] > 0 else 'no_updates'
            })
            
            logger.info(
                f"Repricing concluído: {results['updated']} produtos atualizados"
            )
            
        except Exception as e:
            logger.error(f"Erro no repricing automático: {str(e)}")
            await self.db.automation_logs.insert_one({
                'task': 'auto_repricing',
                'timestamp': datetime.now(timezone.utc),
                'error': str(e),
                'status': 'error'
            })
    
    async def auto_tracking_update(self):
        """Tarefa: Atualização automática de rastreio"""
        try:
            logger.info("Iniciando atualização automática de rastreio...")
            
            results = await self.tracking.track_all_active_orders()
            
            self.stats['last_tracking'] = datetime.now(timezone.utc)
            self.stats['total_trackings'] += 1
            
            # Envia notificações para pedidos que mudaram de status
            if self.notifications_enabled and results['updated'] > 0:
                await self._notify_tracking_updates(results)
            
            # Registra log no banco
            await self.db.automation_logs.insert_one({
                'task': 'auto_tracking',
                'timestamp': datetime.now(timezone.utc),
                'results': results,
                'status': 'success'
            })
            
            logger.info(
                f"Rastreio concluído: {results['updated']} pedidos atualizados, "
                f"{results['delivered']} entregues"
            )
            
        except Exception as e:
            logger.error(f"Erro na atualização de rastreio: {str(e)}")
            await self.db.automation_logs.insert_one({
                'task': 'auto_tracking',
                'timestamp': datetime.now(timezone.utc),
                'error': str(e),
                'status': 'error'
            })
    
    async def _notify_tracking_updates(self, tracking_results: Dict):
        """Envia notificações para pedidos com status atualizado"""
        try:
            # Busca pedidos que foram atualizados recentemente
            recent_orders = await self.db.orders.find({
                'tracking_last_update': {'$exists': True}
            }).to_list(100)
            
            for order in recent_orders:
                # Verifica se o status mudou nas últimas 2 horas
                last_update = order.get('tracking_last_update')
                
                if last_update:
                    time_diff = (datetime.now(timezone.utc) - last_update).total_seconds()
                    
                    # Se foi atualizado nas últimas 2 horas
                    if time_diff < 7200:  # 2 horas
                        await self.notifications.notify_order_status(
                            order['id'],
                            order['status']
                        )
            
        except Exception as e:
            logger.error(f"Erro ao enviar notificações de rastreio: {str(e)}")
    
    async def cleanup_abandoned_carts(self):
        """Tarefa: Limpa carrinhos abandonados há mais de 30 dias"""
        try:
            logger.info("Iniciando limpeza de carrinhos abandonados...")
            
            from datetime import timedelta
            
            # Data limite: 30 dias atrás
            cutoff_date = datetime.now(timezone.utc) - timedelta(days=30)
            
            # Remove carrinhos antigos
            result = await self.db.carts.delete_many({
                'updated_at': {'$lt': cutoff_date},
                'items': {'$size': 0}
            })
            
            logger.info(f"Limpeza concluída: {result.deleted_count} carrinhos removidos")
            
            # Registra log
            await self.db.automation_logs.insert_one({
                'task': 'cleanup_carts',
                'timestamp': datetime.now(timezone.utc),
                'carts_removed': result.deleted_count,
                'status': 'success'
            })
            
        except Exception as e:
            logger.error(f"Erro na limpeza de carrinhos: {str(e)}")
    
    async def daily_report(self):
        """Tarefa: Gera e envia relatório diário"""
        try:
            logger.info("Gerando relatório diário...")
            
            from datetime import timedelta
            
            # Período: últimas 24 horas
            yesterday = datetime.now(timezone.utc) - timedelta(days=1)
            
            # Estatísticas do dia
            stats = {
                'new_orders': await self.db.orders.count_documents({
                    'created_at': {'$gte': yesterday}
                }),
                'total_sales': 0,
                'products_sold': 0,
                'orders_delivered': await self.db.orders.count_documents({
                    'status': 'delivered',
                    'updated_at': {'$gte': yesterday}
                })
            }
            
            # Calcula total de vendas
            orders = await self.db.orders.find({
                'created_at': {'$gte': yesterday}
            }).to_list(None)
            
            for order in orders:
                stats['total_sales'] += order.get('total', 0)
                stats['products_sold'] += len(order.get('items', []))
            
            # Busca admins para enviar relatório
            admins = await self.db.users.find({'role': 'admin'}).to_list(None)
            
            # Envia relatório por email
            subject = f"Relatório Diário - {datetime.now().strftime('%d/%m/%Y')}"
            
            message = f"""
            <html>
            <body>
                <h2>Relatório Diário de Vendas</h2>
                <p><strong>Data:</strong> {datetime.now().strftime('%d/%m/%Y')}</p>
                
                <h3>Resumo do Dia:</h3>
                <ul>
                    <li>Novos Pedidos: {stats['new_orders']}</li>
                    <li>Faturamento Total: R$ {stats['total_sales']:.2f}</li>
                    <li>Produtos Vendidos: {stats['products_sold']}</li>
                    <li>Pedidos Entregues: {stats['orders_delivered']}</li>
                </ul>
                
                <h3>Status de Automação:</h3>
                <ul>
                    <li>Total de Sincronizações: {self.stats['total_syncs']}</li>
                    <li>Total de Repricings: {self.stats['total_repricings']}</li>
                    <li>Total de Rastreios: {self.stats['total_trackings']}</li>
                </ul>
            </body>
            </html>
            """
            
            for admin in admins:
                if admin.get('email'):
                    await self.notifications.send_email(
                        admin['email'],
                        subject,
                        message
                    )
            
            logger.info("Relatório diário enviado com sucesso")
            
            # Registra log
            await self.db.automation_logs.insert_one({
                'task': 'daily_report',
                'timestamp': datetime.now(timezone.utc),
                'stats': stats,
                'status': 'success'
            })
            
        except Exception as e:
            logger.error(f"Erro ao gerar relatório diário: {str(e)}")
    
    def get_stats(self) -> Dict:
        """Retorna estatísticas de automação"""
        return {
            **self.stats,
            'scheduler_running': self.scheduler.running,
            'next_jobs': [
                {
                    'id': job.id,
                    'name': job.name,
                    'next_run': job.next_run_time.isoformat() if job.next_run_time else None
                }
                for job in self.scheduler.get_jobs()
            ]
        }
    
    async def run_task_manually(self, task_name: str) -> Dict:
        """Executa uma tarefa manualmente"""
        tasks = {
            'sync': self.auto_sync_suppliers,
            'repricing': self.auto_repricing,
            'tracking': self.auto_tracking_update,
            'cleanup': self.cleanup_abandoned_carts,
            'report': self.daily_report
        }
        
        if task_name not in tasks:
            return {'success': False, 'error': 'Tarefa não encontrada'}
        
        try:
            await tasks[task_name]()
            return {'success': True, 'task': task_name}
        except Exception as e:
            logger.error(f"Erro ao executar tarefa {task_name}: {str(e)}")
            return {'success': False, 'error': str(e)}
